$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$mascotScript = Join-Path $root 'start-mascote-desktop-v5.ps1'

if (-not (Test-Path -LiteralPath $mascotScript)) {
  throw "Arquivo nao encontrado: $mascotScript"
}

$protocolKey = 'HKCU:\Software\Classes\idvida-mascote'
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$command = '"' + $powershell + '" -NoProfile -WindowStyle Hidden -STA -ExecutionPolicy Bypass -File "' + $mascotScript + '" -StartHidden'

$rootKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Classes\idvida-mascote')
$rootKey.SetValue('', 'URL:Mascote IDvida', [Microsoft.Win32.RegistryValueKind]::String)
$rootKey.SetValue('URL Protocol', '', [Microsoft.Win32.RegistryValueKind]::String)
$rootKey.Close()

$commandKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Classes\idvida-mascote\shell\open\command')
$commandKey.SetValue('', $command, [Microsoft.Win32.RegistryValueKind]::String)
$commandKey.Close()

Write-Host 'Protocolo idvida-mascote instalado com sucesso.'
Write-Host 'Agora a pagina pode abrir o mascote pelo botao Ativar Mascote IDvida.'
