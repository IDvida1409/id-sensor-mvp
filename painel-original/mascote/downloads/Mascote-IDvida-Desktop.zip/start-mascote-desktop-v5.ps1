param(
  [int]$Port = 17323,
  [int]$StartX = -1,
  [int]$StartY = -1,
  [switch]$StartHidden
)

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:FrameRoot = Join-Path $script:Root 'assets\frames-v6-motion'
$script:Mutex = $null
$script:Listener = $null

$createdNew = $false
$script:Mutex = New-Object System.Threading.Mutex($true, 'IDVidaMascoteDesktopV5Discreto', [ref]$createdNew)
if (-not $createdNew) {
  exit 0
}

$script:States = @(
  @{
    Name = 'greet'
    Label = 'Oi, tudo bem? Eu sou assistente virtual IDvida, vou ficar monitorando por aqui.'
    Frames = @(1..14 | ForEach-Object { 'greet-{0:D2}.png' -f $_ })
    FrameMs = 820
    DurationMs = 13000
    BubbleMs = 7000
    Bubble = $true
    Alert = $false
  },
  @{
    Name = 'monitor'
    Label = 'Tudo certo por aqui.'
    Frames = @(1..16 | ForEach-Object { 'monitor-{0:D2}.png' -f $_ })
    FrameMs = 1750
    DurationMs = 0
    BubbleMs = 3200
    Bubble = $true
    Alert = $false
  },
  @{
    Name = 'alert'
    Label = "Geladeira 2 est$([char]0x00E1) h$([char]0x00E1) 30 min`nsem comunica$([char]0x00E7)$([char]0x00E3)o"
    Frames = @(1..14 | ForEach-Object { 'alert-{0:D2}.png' -f $_ })
    FrameMs = 1150
    DurationMs = 16000
    BubbleMs = 9000
    Bubble = $true
    Alert = $true
  }
)

foreach ($state in $script:States) {
  foreach ($frame in $state.Frames) {
    $path = Join-Path $script:FrameRoot $frame
    if (-not (Test-Path -LiteralPath $path)) {
      [System.Windows.MessageBox]::Show("Frame nao encontrado: $path", 'Mascote IDvida') | Out-Null
      exit 1
    }
  }
}

[xml]$xaml = @"
<Window
  xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
  xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
  Title="Mascote IDvida"
  Width="334"
  Height="184"
  WindowStyle="None"
  AllowsTransparency="True"
  Background="Transparent"
  ResizeMode="NoResize"
  ShowInTaskbar="False"
  Topmost="True">
  <Grid x:Name="Root" Background="Transparent">
    <Border x:Name="Bubble" Width="204" Height="74" HorizontalAlignment="Left" VerticalAlignment="Bottom" Margin="0,0,142,62" Background="#BFFFFFFF" BorderBrush="#8823AEEA" BorderThickness="1.2" CornerRadius="8">
      <Border.Effect>
        <DropShadowEffect BlurRadius="10" ShadowDepth="2" Opacity="0.12" Color="#061D38"/>
      </Border.Effect>
      <TextBlock x:Name="BubbleText" Text="Oi, tudo bem? Eu sou assistente virtual IDvida, vou ficar monitorando por aqui." Margin="10,8,10,8" TextWrapping="Wrap" VerticalAlignment="Center" Foreground="#0A4D86" FontFamily="Segoe UI" FontSize="10.5" FontWeight="SemiBold" LineHeight="13"/>
    </Border>
    <Polygon x:Name="Pointer" Points="0,0 12,8 0,16" Fill="#BFFFFFFF" Stroke="#8823AEEA" StrokeThickness="1.2" HorizontalAlignment="Left" VerticalAlignment="Bottom" Margin="198,0,0,83"/>

    <Canvas x:Name="PetHost" Width="142" Height="156" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,6,6" RenderTransformOrigin="0.5,0.86">
      <Canvas.RenderTransform>
        <TransformGroup>
          <ScaleTransform ScaleX="1" ScaleY="1"/>
          <RotateTransform Angle="0"/>
          <TranslateTransform X="0" Y="0"/>
        </TransformGroup>
      </Canvas.RenderTransform>
      <Ellipse x:Name="Shadow" Canvas.Left="30" Canvas.Top="137" Width="80" Height="11" Fill="#3D061D38"/>
      <Image x:Name="PetImage" Canvas.Left="0" Canvas.Top="0" Width="142" Height="142" Stretch="Uniform"/>
      <Button x:Name="CloseButton" Content="X" Canvas.Left="116" Canvas.Top="4" Width="22" Height="22" Background="#FFFFFF" BorderBrush="#C7D6E4" Foreground="#17283E" FontFamily="Segoe UI" FontSize="10" FontWeight="Bold" Cursor="Hand" ToolTip="Fechar mascote"/>
    </Canvas>
  </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$script:Window = [Windows.Markup.XamlReader]::Load($reader)

$script:Bubble = $script:Window.FindName('Bubble')
$script:Pointer = $script:Window.FindName('Pointer')
$script:BubbleText = $script:Window.FindName('BubbleText')
$script:PetHost = $script:Window.FindName('PetHost')
$script:PetImage = $script:Window.FindName('PetImage')
$script:CloseButton = $script:Window.FindName('CloseButton')
$script:Transforms = $script:PetHost.RenderTransform
$script:Scale = $script:Transforms.Children[0]
$script:Rotate = $script:Transforms.Children[1]
$script:Move = $script:Transforms.Children[2]

$script:StateIndex = 0
$script:FrameIndex = 0
$script:Tick = 0
$script:StateStarted = [DateTime]::Now
$script:CurrentFrameMs = 1000
$script:BubbleTimer = $null

function Decode-Url([string]$value) {
  if ($null -eq $value) { return '' }
  return [System.Uri]::UnescapeDataString($value.Replace('+', ' '))
}

function Parse-Query([string]$target) {
  $result = @{}
  $parts = $target.Split('?', 2)
  if ($parts.Count -lt 2) { return $result }
  foreach ($pair in $parts[1].Split('&')) {
    if ([string]::IsNullOrWhiteSpace($pair)) { continue }
    $kv = $pair.Split('=', 2)
    $key = Decode-Url $kv[0]
    $value = if ($kv.Count -gt 1) { Decode-Url $kv[1] } else { '' }
    $result[$key] = $value
  }
  return $result
}

function Send-HttpResponse($client, [int]$status, [string]$body) {
  $statusText = if ($status -eq 200) { 'OK' } elseif ($status -eq 204) { 'No Content' } else { 'Not Found' }
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
  $header = "HTTP/1.1 $status $statusText`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Methods: GET, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type`r`nAccess-Control-Allow-Private-Network: true`r`nContent-Type: application/json; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n"
  $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
  $stream = $client.GetStream()
  $stream.Write($headerBytes, 0, $headerBytes.Length)
  if ($bytes.Length -gt 0) {
    $stream.Write($bytes, 0, $bytes.Length)
  }
  $stream.Flush()
}

function New-Brush([string]$color) {
  $converted = [System.Windows.Media.ColorConverter]::ConvertFromString($color)
  return [System.Windows.Media.SolidColorBrush]::new($converted)
}

function Set-Image([string]$fileName) {
  $path = Join-Path $script:FrameRoot $fileName
  $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
  $bitmap.BeginInit()
  $bitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
  $bitmap.UriSource = [Uri]$path
  $bitmap.EndInit()
  $bitmap.Freeze()
  $script:PetImage.Source = $bitmap
}

function Set-Desktop-Position {
  $workArea = [System.Windows.SystemParameters]::WorkArea
  if ($StartX -ge 0 -and $StartY -ge 0) {
    $script:Window.Left = $StartX
    $script:Window.Top = $StartY
    return
  }

  $script:Window.Left = $workArea.Right - $script:Window.Width - 28
  $script:Window.Top = $workArea.Bottom - $script:Window.Height - 28
}

function Set-State([int]$index) {
  if ($script:BubbleTimer) {
    $script:BubbleTimer.Stop()
  }

  $hasPosition = -not [double]::IsNaN($script:Window.Left) -and -not [double]::IsNaN($script:Window.Top)
  if ($hasPosition) {
    $right = $script:Window.Left + $script:Window.Width
  }

  $script:StateIndex = $index % $script:States.Count
  $script:FrameIndex = 0
  $script:StateStarted = [DateTime]::Now

  $state = $script:States[$script:StateIndex]
  $script:CurrentFrameMs = $state.FrameMs

  $script:BubbleText.Text = $state.Label
  $script:Bubble.Visibility = if ($state.Bubble) { 'Visible' } else { 'Collapsed' }
  $script:Pointer.Visibility = if ($state.Bubble) { 'Visible' } else { 'Collapsed' }

  if ($state.Alert) {
    $script:Window.Width = 384
    $script:Bubble.Width = 224
    $script:Bubble.Height = 86
    $script:Bubble.Margin = [System.Windows.Thickness]::new(0, 0, 142, 62)
    $script:Pointer.Margin = [System.Windows.Thickness]::new(218, 0, 0, 88)
    $script:Bubble.BorderBrush = New-Brush '#F4A51C'
    $script:Bubble.Background = New-Brush '#D9FFFFFF'
    $script:Pointer.Fill = New-Brush '#D9FFFFFF'
    $script:Pointer.Stroke = New-Brush '#F4A51C'
    $script:BubbleText.Foreground = New-Brush '#8B5600'
    $script:BubbleText.FontSize = 11
    $script:BubbleText.LineHeight = 14
  } else {
    $script:Window.Width = 372
    $script:Bubble.Width = 204
    $script:Bubble.Height = 74
    $script:Bubble.Margin = [System.Windows.Thickness]::new(0, 0, 142, 62)
    $script:Pointer.Margin = [System.Windows.Thickness]::new(198, 0, 0, 83)
    $script:Bubble.BorderBrush = New-Brush '#23AEEA'
    $script:Bubble.Background = New-Brush '#BFFFFFFF'
    $script:Pointer.Fill = New-Brush '#BFFFFFFF'
    $script:Pointer.Stroke = New-Brush '#23AEEA'
    $script:BubbleText.Foreground = New-Brush '#0A4D86'
    $script:BubbleText.FontSize = 10.5
    $script:BubbleText.LineHeight = 13
  }

  Set-Image $state.Frames[0]

  if ($state.Bubble -and $script:BubbleTimer -and $state.BubbleMs -gt 0) {
    $script:BubbleTimer.Interval = [TimeSpan]::FromMilliseconds($state.BubbleMs)
    $script:BubbleTimer.Start()
  }

  if ($hasPosition) {
    $script:Window.Left = $right - $script:Window.Width
  }
}

function Show-Mascot {
  if (-not $script:Window.IsVisible) {
    $script:Window.Show()
  }
  $script:Window.Topmost = $true
  $script:Window.Activate() | Out-Null
}

function Show-Alert([hashtable]$data = @{}) {
  $device = if ($data.ContainsKey('device') -and $data.device) { $data.device } else { 'Geladeira 2' }
  $time = if ($data.ContainsKey('time') -and $data.time) { $data.time } elseif ($data.ContainsKey('minutes') -and $data.minutes) { "$($data.minutes) min" } else { '30 min' }
  $local = if ($data.ContainsKey('local') -and $data.local) { $data.local } else { "Laborat$([char]0x00F3)rio IDvida" }
  $area = if ($data.ContainsKey('area') -and $data.area) { $data.area } else { "$([char]0x00C1)rea fria" }

  Set-State 2
  $script:BubbleText.Text = "$device est$([char]0x00E1) h$([char]0x00E1) $time`nsem comunica$([char]0x00E7)$([char]0x00E3)o.`n$local / $area"
  Show-Mascot
}

function Advance-Frame {
  $state = $script:States[$script:StateIndex]
  $script:FrameIndex = ($script:FrameIndex + 1) % $state.Frames.Count
  Set-Image $state.Frames[$script:FrameIndex]
}

$script:CloseButton.Add_Click({
  $script:Window.Close()
})

$script:Window.Add_MouseLeftButtonDown({
  if ($_.OriginalSource -is [System.Windows.Controls.Button]) { return }
  try { $script:Window.DragMove() } catch {}
})

$script:MotionTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:MotionTimer.Interval = [TimeSpan]::FromMilliseconds(40)
$script:MotionTimer.Add_Tick({
  $script:Tick += 1
  $state = $script:States[$script:StateIndex]
  $wave = [Math]::Sin($script:Tick / 38.0)

  if ($state.Name -eq 'monitor') {
    $script:Move.Y = 3 + ($wave * -2.2)
    $script:Rotate.Angle = $wave * .22
    $script:Scale.ScaleX = .96
    $script:Scale.ScaleY = .96
  } elseif ($state.Name -eq 'alert') {
    $script:Move.Y = [Math]::Sin($script:Tick / 9.0) * -5
    $script:Rotate.Angle = [Math]::Sin($script:Tick / 11.0) * .8
    $script:Scale.ScaleX = 1
    $script:Scale.ScaleY = 1
  } else {
    $script:Move.Y = $wave * -3.5
    $script:Rotate.Angle = $wave * .45
    $script:Scale.ScaleX = 1
    $script:Scale.ScaleY = 1
  }

  $elapsed = ([DateTime]::Now - $script:StateStarted).TotalMilliseconds
  if ($state.DurationMs -gt 0 -and $elapsed -gt $state.DurationMs) {
    if ($state.Name -eq 'greet' -or $state.Name -eq 'alert') {
      Set-State 1
    }
  }
})

$script:FrameTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:FrameTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$script:FrameTimer.Add_Tick({
  $state = $script:States[$script:StateIndex]
  $script:FrameTimer.Interval = [TimeSpan]::FromMilliseconds($script:CurrentFrameMs)
  Advance-Frame
})

$script:BubbleTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:BubbleTimer.Interval = [TimeSpan]::FromMilliseconds(5000)
$script:BubbleTimer.Add_Tick({
  $script:BubbleTimer.Stop()
  $script:Bubble.Visibility = 'Collapsed'
  $script:Pointer.Visibility = 'Collapsed'
})

$script:ServerTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:ServerTimer.Interval = [TimeSpan]::FromMilliseconds(120)
try {
  $script:Listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Parse('127.0.0.1'), $Port)
  $script:Listener.Start()
  $script:ServerTimer.Add_Tick({
    while ($script:Listener -and $script:Listener.Pending()) {
      $client = $script:Listener.AcceptTcpClient()
      try {
        $client.ReceiveTimeout = 800
        $stream = $client.GetStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII)
        $line = $reader.ReadLine()
        if ([string]::IsNullOrWhiteSpace($line)) {
          Send-HttpResponse $client 200 '{"ok":true}'
          continue
        }
        do {
          $headerLine = $reader.ReadLine()
        } while ($null -ne $headerLine -and $headerLine -ne '')

        $parts = $line.Split(' ')
        $method = $parts[0]
        $target = if ($parts.Count -gt 1) { $parts[1] } else { '/' }
        if ($method -eq 'OPTIONS') {
          Send-HttpResponse $client 204 ''
          continue
        }

        $path = $target.Split('?', 2)[0].ToLowerInvariant()
        $query = Parse-Query $target

        if ($path -eq '/health') {
          Send-HttpResponse $client 200 '{"ok":true,"service":"mascote-idvida-v6"}'
        } elseif ($path -eq '/activate' -or $path -eq '/greet' -or $path -eq '/show') {
          Set-State 0
          Show-Mascot
          Send-HttpResponse $client 200 '{"ok":true,"action":"greet"}'
        } elseif ($path -eq '/monitor' -or $path -eq '/ok' -or $path -eq '/sit') {
          Set-State 1
          Show-Mascot
          Send-HttpResponse $client 200 '{"ok":true,"action":"monitor"}'
        } elseif ($path -eq '/alert') {
          Show-Alert $query
          Send-HttpResponse $client 200 '{"ok":true,"action":"alert"}'
        } elseif ($path -eq '/hide') {
          $script:Window.Hide()
          Send-HttpResponse $client 200 '{"ok":true,"action":"hide"}'
        } elseif ($path -eq '/close' -or $path -eq '/exit') {
          Send-HttpResponse $client 200 '{"ok":true,"action":"close"}'
          $script:Window.Close()
        } else {
          Send-HttpResponse $client 404 '{"ok":false}'
        }
      } catch {
        try { Send-HttpResponse $client 500 '{"ok":false}' } catch {}
      } finally {
        $client.Close()
      }
    }
  })
} catch {
  [System.Windows.MessageBox]::Show("Nao foi possivel abrir a porta local $Port.`n$($_.Exception.Message)", 'Mascote IDvida') | Out-Null
}

$script:Window.Add_Closed({
  if ($script:MotionTimer) { $script:MotionTimer.Stop() }
  if ($script:FrameTimer) { $script:FrameTimer.Stop() }
  if ($script:BubbleTimer) { $script:BubbleTimer.Stop() }
  if ($script:ServerTimer) { $script:ServerTimer.Stop() }
  if ($script:Listener) { $script:Listener.Stop() }
  if ($script:Mutex) {
    $script:Mutex.ReleaseMutex()
    $script:Mutex.Dispose()
  }
  [System.Windows.Application]::Current.Shutdown()
})

$app = [System.Windows.Application]::Current
if ($null -eq $app) {
  $app = New-Object System.Windows.Application
}
$app.ShutdownMode = [System.Windows.ShutdownMode]::OnExplicitShutdown

Set-State 0
Set-Desktop-Position
$script:MotionTimer.Start()
$script:FrameTimer.Start()
if ($script:Listener) { $script:ServerTimer.Start() }
if (-not $StartHidden) {
  Show-Mascot
}
$app.Run() | Out-Null
