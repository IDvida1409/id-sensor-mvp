@echo off
title Instalador Mascote IDvida
set "SCRIPT_DIR=%~dp0"

echo.
echo Instalando o Mascote IDvida neste usuario do Windows...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%instalar-protocolo-mascote-idvida.ps1"

echo.
echo Instalacao concluida.
echo Agora volte para a pagina do Mascote IDvida e clique em Ativar Mascote IDvida.
echo.
start "" "https://id-sensor-mvp.onrender.com/mascote"
pause
